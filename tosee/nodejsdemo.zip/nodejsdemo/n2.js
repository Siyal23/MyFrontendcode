console.log("n2.js file loaded");
x = 10;

module.exports = {
  hb: function () {
    console.log("Hello Buddy");
  },
  hh: function () {
    console.log("Hello Hello");
  },
};
// function hello(){
//     console.log("Hello HELLO");
// }
//module.exports = {}
//export default  {hi,hello}
