var n =  require ("./n2")

console.log("Hello Node");

console.log(x);

n.hb();
n.hh();



//n.hello();


